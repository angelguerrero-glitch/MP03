/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codifont;
import static metodes.Cadena.juntaSaltejats;

/**
 *
 * @author Angel Guerrero
 */
public class Practica2 {
    public static void main(String[] args) {
        System.out.println(juntaSaltejats(0));
        System.out.println(juntaSaltejats(4));
        System.out.println(juntaSaltejats(4,null));
        System.out.println(juntaSaltejats(0,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(1,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(2,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(3,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(4,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(5,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(6,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(7,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(8,"La","teua","reposta","no","es ","la","correcta."));
        System.out.println(juntaSaltejats(9,"La","teua","reposta","no","es ","la","correcta."));
    }
    
}
